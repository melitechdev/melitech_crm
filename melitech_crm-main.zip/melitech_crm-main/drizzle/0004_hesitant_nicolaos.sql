DROP TABLE `auditLogs`;--> statement-breakpoint
DROP TABLE `communicationLogs`;--> statement-breakpoint
DROP TABLE `guestClients`;--> statement-breakpoint
DROP TABLE `inventoryTransactions`;--> statement-breakpoint
DROP TABLE `reminders`;--> statement-breakpoint
DROP TABLE `scheduledReminders`;--> statement-breakpoint
DROP TABLE `stockAlerts`;--> statement-breakpoint
DROP TABLE `systemSettings`;--> statement-breakpoint
DROP TABLE `userPermissions`;